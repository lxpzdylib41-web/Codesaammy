-- AutoCodesGUI.lua
-- Plantilla inicial
print("Auto Codes GUI placeholder")
-- Debido al límite del chat, el GUI completo no se generó automáticamente.
-- Pide la versión completa y se puede entregar por partes.
